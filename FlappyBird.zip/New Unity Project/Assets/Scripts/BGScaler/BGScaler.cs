﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGScaler : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        Vector3 temScale = transform.localScale; //lấy scale hiện tại

        float height = sr.bounds.size.y; //tính biên chiều cao
        float width = sr.bounds.size.x; //tính biên chiều rộng

        float worldHeight = Camera.main.orthographicSize * 2f;
        float worldWidth = worldHeight * Screen.width / Screen.height;

        temScale.y = worldHeight / height;
        temScale.x = worldWidth / width;
        transform.localScale = temScale;

    }

}
